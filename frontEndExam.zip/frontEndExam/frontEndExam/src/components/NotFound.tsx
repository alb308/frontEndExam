import React from 'react';

const NotFound: React.FC = () => {
  return (
    <div style={{ padding: '2px', textAlign: 'center' }}>
      <h1>404 - Pagina non trovata</h1>
    </div>
  );
};

export default NotFound;
