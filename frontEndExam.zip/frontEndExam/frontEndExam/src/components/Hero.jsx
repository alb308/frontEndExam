import React from "react";

function Hero() {
  return (
    <section>
      <h1>BEVANDE MONSTER ENERGY</h1>
      <p>Ho iniziato questa passione per le lattine il 1° aprile 2018...</p>
    </section>
  );
}

export default Hero;
